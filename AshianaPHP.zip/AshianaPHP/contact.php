<?php
include("header.php");

?>
<!--//===================================================-->
        <!-- Page Title -->
        <div class="page-title-container">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 wow fadeIn" style="text-align:center;font-size:25px;">
                        <i class="fa fa-user"></i>
                        <h1 style="font-size:35px;">Contact Us</h1>
                    </div>
                </div>
            </div>
        </div>

        <!-- About Us Text -->
        <div class="about-us-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-12 about-us-text wow fadeInLeft">
<!--//===================================================-->


<div style="height:300px;">

<div style="float:left;width:50%;height:300px;font-size:25px;text-align:center;padding-top:20px;">

				<br>Address: G-8 Area, Rajouri Garden
				<br>New Delhi-64
				<br>Get In Touch
				<br>Telephone:  234 567 9871
				<br>E-mail: mail@example.com
</div>


<div style="float:left;width:50%;height:300px;">
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.9280437761727!2d77.11616023215461!3d28.631918618721116!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d03437774bf6d%3A0x68966aea6bc15b7e!2sGuru+Tegh+Bahadur+Institute+of+Technology!5e0!3m2!1sen!2sin!4v1507448711616" width=100% height=300px; frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

</div>






<?php
include("footer.php");
?>